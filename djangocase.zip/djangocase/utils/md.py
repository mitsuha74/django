from django.utils.deprecation import MiddlewareMixin
from django.shortcuts import render,redirect,HttpResponse

class DemoMiddleware(MiddlewareMixin):
    def process_request(self,request):
        # print('laile')
        if request.path_info == '/login/':
            return
        user_info = request.session.get('user_info')
        if user_info:
            return
        return redirect('/login/')

    def process_response(self,request,response):
        # print('zuole')
        return response
