from django.shortcuts import render,redirect,HttpResponse
from app01 import models
import re
from django.core.exceptions import ValidationError
from utils.pagination import Pagination
from django.db.models import Q
# Create your views here.
def login(request):
    if request.method == 'GET':
        return render(request,'login.html')
    user = request.POST.get('username')
    pwd = request.POST.get('password')
    admin_obj = models.Admin.objects.filter(username=user,password=pwd).first()
    if admin_obj:
        print('当前登录用户信息',admin_obj.id,admin_obj.username,admin_obj.password)
        request.session['user_info'] = {'id':admin_obj.id,'username':admin_obj.username}
        return redirect('/depart/list/')
    else:
        return render(request,'login.html',{'error':'用户名或密码错误'})

def logout(request):
    request.session.clear()
    return redirect('/login/')

def depart_list(request):
    query = models.DepartMent.objects.all()
    page = Pagination(request,query.count())
    queryset = query[page.start:page.end]
    context = {
        'infos':queryset,
        'page_string':page.html()
    }
    return render(request,'depart_list.html',context)
def depart_add(request):
    if request.method == 'GET':
        return render(request,'depart_add.html')
    title = request.POST.get('title')  # 通过name标签
    models.DepartMent.objects.create(title=title)
    return redirect('/depart/list/')

def depart_delete(request):
    did = request.GET.get('did')
    models.DepartMent.objects.filter(id=did).delete()
    return redirect('/depart/list/')

def depart_edit(request):
    if request.method == 'GET':
        did = request.GET.get('did')
        obj = models.DepartMent.objects.filter(id=did).first()
        return render(request,'depart_edit.html',{'id':did,'title':obj.title})
    did = request.GET.get('did')
    title = request.POST.get('title')
    models.DepartMent.objects.filter(id=did).update(title=title)
    return redirect('/depart/list/')


def assert_list(request):
    key = request.GET.get('key','')
    q = Q()
    if key:
        q.connector = 'OR'
        q.children.append(('name__contains',key))
        q.children.append(('depart__title__contains',key))
    infos = models.AssetSet.objects.filter(q)
    page = Pagination(request,infos.count())
    infoset = infos[page.start:page.end]
    context = {
        'infos':infoset,
        'key':key,
        'page_string':page.html(),
    }
    return render(request,'assert_list.html',context)

from  django import forms

class AessertModelForm(forms.ModelForm):
    class Meta:
        model = models.AssetSet
        fields = ['name','price','category','depart']
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        for name,field in self.fields.items():
            field.widget.attrs['class']='form-control'

def assert_add(request):
    if request.method == 'GET':
        form = AessertModelForm()
        return render(request,'assert_add.html',{'form':form})
    form = AessertModelForm(data=request.POST)
    if form.is_valid():
        form.save()
        return redirect('/assert/list/')
    else:
        return render(request,'assert_add.html',{'form':form})

def assert_edit(request):
    aid = request.GET.get('aid')
    assert_obj = models.AssetSet.objects.filter(id=aid).first()
    if request.method == 'GET':
        form = AessertModelForm(instance=assert_obj)
        return render(request,'assert_edit.html',{'form':form})
    form = AessertModelForm(data=request.POST,instance=assert_obj)
    if form.is_valid():
        form.save()
        return redirect('/assert/list/')
    else:
        return render(request,'assert_edit.html',{'form':form})

def assert_delete(request,aid):
    models.AssetSet.objects.filter(id=aid).delete()
    return redirect('/assert/list/')

# def user_list(request):
#     field_list = [('name__contains','姓名'),('email__contains','邮箱'),('phone__contains','手机号')]
#     condition = {}
#     key = request.GET.get('key','')
#     field = request.GET.get('field')
#     if key:
#         condition[field] = key.strip()
#     infos = models.User.objects.filter(**condition)
#     return render(request, 'user_list.html', {'infos': infos,'key':key,'field':field,'field_list':field_list})

def user_list(request):
    from django.db.models import Q
    key = request.GET.get('key','')
    q = Q()
    if key:
        q.connector = 'OR'
        q.children.append(('name__contains',key))
        q.children.append(('phone__contains',key))
        q.children.append(('email__contains',key))
        q.children.append(('depart__title__contains',key))
    infos = models.User.objects.filter(q)
    page = Pagination(request,infos.count())
    infoset = infos[page.start:page.end]
    context = {
        'infos':infoset,
        'key':key,
        'page_string':page.html()
    }
    return render(request,'user_list.html',context)

class UserModelForm(forms.ModelForm):
    class Meta:
        model = models.User
        fields = '__all__'
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        for name,field in self.fields.items():
            field.widget.attrs['class']='form-control'

    def clean_phone(self):
        value = self.cleaned_data['phone']
        if not re.match(r'1[3578]\d{9}',value):
            raise ValidationError('手机格式不正确')
        # 如果是新增时，手机号需要与数据库中的手机号进行校验，否则不需要进行校验
        if self.instance.pk:
            exists = models.User.objects.filter(phone=value).exclude(id=self.instance.pk).exists()
        else:
            exists = models.User.objects.filter(phone=value).exists()
        if exists:
            raise ValidationError('手机号已经存在')
        return value

def user_add(request):
    if request.method == 'GET':
        form = UserModelForm()
        return render(request, 'assert_add.html', {'form': form})
    form = UserModelForm(data=request.POST)
    if form.is_valid():
        form.save()
        return redirect('/user/list/')
    else:
        return render(request,'user_add.html',{'form':form})

def user_edit(request,uid):
    user_obj = models.User.objects.filter(id=uid).first()
    if request.method=='GET':
        form = UserModelForm(instance=user_obj)
        return render(request,'user_edit.html',{'form':form})
    form = UserModelForm(data=request.POST,instance=user_obj)
    if form.is_valid():
        form.save()
        return redirect('/user/list/')
    return render(request,'user_edit.html',{'form':form})
